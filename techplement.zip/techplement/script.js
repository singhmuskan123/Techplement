document.getElementById('getWeatherBtn').addEventListener('click', getWeather);

function getWeather() {
    const city = document.getElementById('cityInput').value;
    const apiKey = '73d129b121768f58714f6b45af8b918d';  
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                const cityName = data.name;
                const temperature = data.main.temp;

                document.getElementById('cityName').innerText = cityName;
                document.getElementById('temperature').innerText = `Temperature: ${temperature}°C`;
            } else {
                alert('City not found. Please try again.');
            }
        })
        .catch(error => {
            alert('Error fetching weather data. Please try again.');
            console.error('Error:', error);
        });
}
